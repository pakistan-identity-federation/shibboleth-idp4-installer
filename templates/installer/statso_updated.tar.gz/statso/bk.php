 <html>
  <?php
   include 'header.php'; 
   set_time_limit(600);
  ?>
    <div id="content">
      <div class="container">
        <div class="crumbs">
          <ul id="breadcrumbs" class="breadcrumb">
            <li> <i class="icon-home">
  </i> <a href="index.php">Dashboard</a> </li>
            <li class="current"> <a href="index.php" title="">Statistics</a> </li>
          </ul>
          <ul class="crumb-buttons">
            <li id="reportrange"> <a href="#">
   Select Date :
  <i class="icon-calendar">
  </i>
  <span>
  </span>
  <i class="icon-angle-down">
  </i>
  </a> </li>
          </ul>
        </div>
        <div class="row  row-bg">
          <div class="col-sm-6 col-md-4 hidden-xs" data-toggle="modal" data-target="#myModal1">
            <div class="statbox widget box box-shadow">
              <div class="widget-content">
                <div class="visual green"> <i class="icon-user">
  </i> </div>
                <div class="title">Unique Users</div>
                <div class="value" id="uidstotal">0</div> <a class="more" role="dialog" data-show="modal" data-target="#myModal1">View More <i class="pull-right icon-angle-right">
  </i>
  </a> </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4 hidden-xs" data-toggle="modal" data-target="#myModal2">
            <div class="statbox widget box box-shadow">
              <div class="widget-content">
                <div class="visual yellow"> <i class="icon-book">
  </i> </div>
                <div class="title">Unique Publishers</div>
                <div class="value" id="rptotal">0</div> <a class="more" data-toggle="modal_publisher" data-target="#myModal2">View More <i class="pull-right icon-angle-right">
  </i>
  </a> </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4 hidden-xs" data-toggle="modal" data-target="#myModal3">
            <div class="statbox widget box box-shadow">
              <div class="widget-content">
                <div class="visual red"> <i class="icon-lock">
  </i> </div>
                <div class="title">Total Logins</div>
                <div class="value" id="logintotal">0</div> <a class="more" data-show="modal" data-target="#myModal3">View More <i class="pull-right icon-angle-right">
  </i>
  </a> </div>
            </div>
          </div>
        </div>
        <div id="stats">
          <div class="col-md-6">
            <div class="widget">
              <div class="widget-content">
                <div class="tabbable tabbable-custom">
                  <ul class="nav nav-tabs">
                    <li class="active"> <a href="#tab_feed_1" data-toggle="tab">Publisher Statistics</a> </li>
                  </ul>
                  <div class="tab-content">
                    <div class="tab-pane active" id="tab_feed_1">
                      <!-- <div class="title">
                       <div class="col-md-8">Publisher</div>
                       <div class="col-md-4">Count</div>
                      </div> -->
                      <div class="scroller" data-height="300px" data-always-visible="1" data-rail-visible="0">
                        <ul class="feeds clearfix" id="rp"> </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="widget">
              <div class="widget-content">
                <div class="tabbable tabbable-custom">
                  <ul class="nav nav-tabs">
                    <li class="active"> <a href="#tab_feed_1" data-toggle="tab">User Statistics</a> </li>
                  </ul>
                  <div class="tab-content">
                    <div class="tab-pane active" id="tab_feed_1">
                      <div class="scroller" data-height="300px" data-always-visible="1" data-rail-visible="0">
                        <ul class="feeds clearfix" id="user"> </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- modal for unique users -->
            <div class="col-md-12">
              <div class="modal fade" id="myModal1">
                <div class="modal-dialog" style="width:80%;">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title">
                    <i class="icon-user">
                    </i> User Statistics
                    </h4> </div>
                    <div class="modal-body">
                      <div class="widget-content">
                        <div id="chartdiv1" style="height:500px;width:100%;"></div>
                      </div>
                    </div>

                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- modal for unique users -->

            <!-- modal for Publisher -->
            <div class="col-md-12">
              <div class="modal fade" id="myModal2">
                <div class="modal-dialog" style="width:80%;">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title">
                        <i class="icon-book">
                        </i> Publisher Statistics
                        </h4> 
                    </div>  
                    <div class="modal-body">
                      <div class="widget-content">
                        <div id="chartdiv" style="height:500px;width:100%;"></div>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- modal for Publisher -->

            <!-- modal for logs -->
            <div class="col-md-12">
              <div class="modal fade" id="myModal3">
                <div class="modal-dialog" style="width:80%;">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                      <h4 class="modal-title">
                        <i class="icon-user"></i> Total Logs
                      </h4> 
                    </div>
                    <div class="modal-body">
                      <div class="widget-content">
                        <table id="ex2" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                          <thead style="background: #F9F9F9;">
                            <tr>
                              <th>Date</th>
                              <th>IP</th>
                              <th>User</th>
                              <th>Publisher</th>
                            </tr>
                          </thead>
                          <tbody> </tbody>
                          <!-- <tfoot> </tfoot> -->
                        </table>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- modal for logs -->

          </div>

          <div class="col-md-12">
            <div class="widget box">
              <div class="widget-header">
                <h4>
                <i class="icon-lock">
                </i> Log Statstics</h4> 
              </div>
              <div class="widget-content">
                <div class="tabbable tabbable-custom">
                  <ul class="nav nav-tabs">
                    <div class="tab-content">
                      <div class="tab-pane active" id="tab_feed_1">
                        <table id="example" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
                          <thead style="background: #F9F9F9;">
                            <tr>
                              <th>Date</th>
                              <th>IP</th>
                              <th>User</th>
                              <th>Publisher</th>
                            </tr>
                          </thead>
                          <tfoot> </tfoot>
                          <tbody> </tbody>
                        </table>
                      </div>
                    </div>
                  </ul>
                </div>
              </div>
            </div>
          </div>
                </body>
                
  </html>
<script type="text/javascript">
$(document).ready(function() {
  var div = document.getElementById('stats');
  div.style.display = 'none';

  display();
  calculate();

});
function display(e){
//  e.preventDefault();
task = 'fetch_all_logs';
  $.ajax({
    url: "fetch_log.php",
    type:"post",
    data:{
      task : task,
    },
    dataType: 'json',
    success: function(data) {
      alert(data);
      console.log(data);
    }


  });
}
  /*function calculate() {
   
    $.ajax({
      url: "getcontent.php",
      type: "POST",
      success: function(result) {
        function isJson(str) {
          try {
            JSON.parse(str); 
          } catch(e) {
            return false;
          }
          return true; 
        } 
        if(isJson(result) == true) {
          document.getElementById('stats').style.display = "block";
          var obj = JSON.parse(result);
          document.getElementById('logintotal').innerHTML = obj.count_total_logins; 
          document.getElementById("rptotal").innerHTML = obj.count_unique_rp; 
          document.getElementById("uidstotal").innerHTML = obj.count_unique_user; 
          var rpstats = [];
          var userstats = [];
          Object.keys(obj.count_per_rp).forEach(function(n, i) {
            var v = obj.count_per_rp[n];
            rpstats.push({
              rp: n,
              count: v,
            });
          });
          Object.keys(obj.count_per_user).forEach(function(n, i) {
            var v = obj.count_per_user[n];
            userstats.push({
              user: n,
              count: v,
            });
          });
          var chart = AmCharts.makeChart("chartdiv", {
            "autoMargins": false,
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "width": 1500,
            "height": 500,
            "type": "pie",
            "startDuration": 0,
            "theme": "light",
            "addClassNames": true,
            "legend": {
              "position": "bottom",
              "marginRight": 50,
              "marginLeft": 50,
              "autoMargins": false
            },
            "innerRadius": "0%",
            "defs": {
              "filter": [{
                "id": "shadow",
                "width": "50%",
                "height": "300%",
                "feOffset": {
                  "result": "offOut",
                  "in": "SourceAlpha",
                  "dx": 0,
                  "dy": 0
                },
                "feGaussianBlur": {
                  "result": "blurOut",
                  "in": "offOut",
                  "stdDeviation": 5
                },
                "feBlend": {
                  "in": "SourceGraphic",
                  "in2": "blurOut",
                  "mode": "normal"
                }
              }]
            },
            "dataProvider": rpstats,
            "valueField": "count",
            "titleField": "rp",
            "depth3D": 10,
            "angle": 30,
            "outlineAlpha": 0.1,
            "export": {
              "enabled": true,
              "libs": {
                "path": "libs/"
              },
              "fileName": "publisherstats",
            }
          });
          var chart = AmCharts.makeChart("chartdiv1", {
            "autoMargins": false,
            "marginTop": 0,
            "marginBottom": 0,
            "marginLeft": 0,
            "width": 1500,
            "height": 500,
            "type": "pie",
            "startDuration": 0,
            "theme": "light",
            "addClassNames": true,
            "legend": {
              "position": "bottom",
              "marginRight": 50,
              "marginLeft": 50,
              "autoMargins": false
            },
            "innerRadius": "0%",
            "defs": {
              "filter": [{
                "id": "shadow",
                "width": "200%",
                "height": "200%",
                "feOffset": {
                  "result": "offOut",
                  "in": "SourceAlpha",
                  "dx": 0,
                  "dy": 0
                },
                "feGaussianBlur": {
                  "result": "blurOut",
                  "in": "offOut",
                  "stdDeviation": 5
                },
                "feBlend": {
                  "in": "SourceGraphic",
                  "in2": "blurOut",
                  "mode": "normal"
                }
              }]
            },
            "dataProvider": userstats,
            "valueField": "count",
            "titleField": "user",
            "outlineAlpha": 0.1,
            "depth3D": 15,
            "angle": 30,
            "export": {
              "enabled": true,
              "libs": {
                "path": "libs/"
              },
              "fileName": "userstats",
            }
          });
          chart.addListener("init", handleInit);
          chart.addListener("rollOverSlice", function(e) {
            handleRollOver(e);
          });

          function handleInit() {
            chart.legend.addListener("rollOverItem", handleRollOver);
          }

          function handleRollOver(e) {
            var wedge = e.dataItem.wedge.node;
            wedge.parentNode.appendChild(wedge);
          }

          function sortResults(arr, prop, asc) {
            arr = arr.sort(function(a, b) {
              if(asc) {
                return(a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
              } else {
                return(b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
              }
            });
            return arr;
          }
          rpc = sortResults(rpstats, 'count', false);
          userc = sortResults(userstats, 'count', false);
          $.each(rpc, function(index, s) {
            $('#rp').append('<li>' + '<div class="col1">' + '<div class="content">' + '<div class="content-col1">' + '<div class="label label-success">' + '<i class="icon-book">' + '</i>' + '</div>' + '</div>' + '<div class="content-col2"  >' + '<div class="desc" id="4">' + s.rp + '</div>' + '</div>' + '</div>' + '</div>' + '<div class="col2">' + '<div class="date" id="u3">' + s.count + '</div>' + '</div>' + '</div>');
          });
          $.each(userc, function(index, s) {
            $('#user').append('<li>' + '<div class="col1">' + '<div class="content">' + '<div class="content-col1">' + '<div class="label label-danger">' + '<i class="icon-user">' + '</i>' + '</div>' + '</div>' + '<div class="content-col2"  >' + '<div class="desc" id="4">' + s.user + '</div>' + '</div>' + '</div>' + '</div>' + '<div class="col2">' + '<div class="date" id="u3">' + s.count + '</div>' + '</div>' + '</div>');
          });
          $.fn.dataTableExt.oSort['time-date-sort-pre'] = function(value) {
            return Date.parse(value);
          };
          $.fn.dataTableExt.oSort['time-date-sort-asc'] = function(a, b) {
            return a - b;
          };
          $.fn.dataTableExt.oSort['time-date-sort-desc'] = function(a, b) {
            return b - a;
          };
          $('#example').DataTable({
            "lengthMenu": [
              [25, 50, 100, -1],
              [25, 50, 100, "All"]
            ],
            "destroy": true,
            "data": obj.logs,
            "columns": [{
              "data": "datetime",
              "type": 'time-date-sort',
            }, {
              "data": "ip"
            }, {
              "data": "user"
            }, {
              "data": "rp"
            }, ],
            dom: 'Bfrtip',
            buttons: ['pageLength', {
              extend: 'collection',
              text: 'Export',
              buttons: [{
                extend: 'excel',
                title: 'User Logs'
              }, {
                extend: 'csv',
                title: 'User Logs'
              }, {
                extend: 'pdf',
                title: 'User Logs'
              }, {
                extend: 'print',
                title: 'User Logs'
              }, ]
            }],
          });
          $('#ex2').DataTable({
            "order": [0, "desc"],
            "lengthMenu": [
              [25, 50, 100, -1],
              [25, 50, 100, "All"]
            ],
            "destroy": true,
            "data": obj.logs,
            "columns": [{
              "data": "log_date"
            }, {
              "data": "ip_address"
            }, {
              "data": "user"
            }, {
              "data": "sp"
            }, ],
            dom: 'Bfrtip',
          });
        } else {

          //alert(result);
        }
      },

      error: function(result, status) {
        alert("Error!!" + status + " Plese Try again..");
      }
    //});
  }); 
  }*/
  var start = moment().subtract(29, 'days');
  var end = moment();
  var startdate = start.format('YYYY-MM-DD');
  var enddate = end.format('YYYY-MM-DD');

  function cb(start, end) {
    $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    document.getElementById("user").innerHTML = "";
    document.getElementById("rp").innerHTML = "";
    calculate(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
  }
  $('#reportrange').daterangepicker({
    startDate: start,
    endDate: end,
    ranges: {
      'Today': [moment(), moment()],
      'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
      'Last 7 Days': [moment().subtract(6, 'days'), moment()],
      'Last 30 Days': [moment().subtract(29, 'days'), moment()],
      'This Month': [moment().startOf('month'), moment().endOf('month')],
      'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    }
  }, cb);
  cb(start, end);

//}); 
</script>
