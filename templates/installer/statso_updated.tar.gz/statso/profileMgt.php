<?php include 'dbconfig.php'; 
session_start();

if(isset($_POST['edit']))
{
		    $Id=$_POST['id'];
        $name         = mysql_real_escape_string( $_POST['name']);
 		    $username     = mysql_real_escape_string( $_POST['username']);
        $email        = mysql_real_escape_string($_POST['email']);  
        $designation  = mysql_real_escape_string($_POST['designation']);        
        $role         = mysql_real_escape_string($_POST['role']);
        
$sql_query = "UPDATE users SET name='$name',email='$email',role='$role',username='$username',designation='$designation' WHERE id='$Id'";
    $retval = mysql_query($sql_query);
 if(! $retval ) {
     $msg="<strong>Oh snap!</strong> ERROR ! could not update data";
      Header( 'Location:  profile.php?error=1&msg='.$msg );
   }
   $msg="<strong>SUCCESS</strong> Changes are saved successfully";
   Header( 'Location:  profile.php?success=1&msg='.$msg) ;
   mysql_close($conn);
     

}
                
 if(isset($_GET['delete']))
{
		$Id=$_GET['id'];
 	
        
  $sql_query = "DELETE FROM users WHERE id='$Id'";
    $retval = mysql_query($sql_query);
	 if(! $retval ) {
 	$msg="<strong>Oh snap!</strong> ERROR ! could not delete data";
      Header( 'Location: userStatus.php?error=1&msg='.$msg );
   }
   $msg="<strong>SUCCESS</strong> Deleted successfully";
   Header( 'Location: userStatus.php?success=1&msg='.$msg) ;
  
   mysql_close($conn);
    
}


 
 ?>   