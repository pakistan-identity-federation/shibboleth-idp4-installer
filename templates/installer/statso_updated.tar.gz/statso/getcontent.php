<?php
ini_set('memory_limit', '-1');
ini_set('max_execution_time', -1);
require __DIR__ . '/apache2-log-parser-master/vendor/autoload.php';

include 'dbconfig.php';

$y = date('Y'); 
$m = date('m');

$m = date('m', strtotime("-0 month"));
//$d = (date('d', strtotime("-1 day")));
//$d = date('d');

$rundate = $y.$m.$d;
$firstdate = date("Y-m-01", strtotime($rundate));
$firstday = date('d', strtotime($firstdate));
$lastdate = date("Y-m-t", strtotime($rundate));
$lastday = date('d', strtotime($lastdate));

$list = [];
for($d=$firstday; $d<=$lastday; $d++){
    $time=mktime(12, 0, 0, $m, $d, $y);
    if (date('m', $time)==$m)
        //print_r($list[]=date('Y-m-d', $time));
    $list[] = date('Y-m-d', $time);
}

foreach ($list as $row) {
//$source_folder ="logsnew/";  
$source_folder = "/opt/shibboleth-idp/logs";
$pattern="idp-audit";
$ext = '.log';
$fname = $pattern.'-'.$row.$ext;

$files=glob_files($source_folder,$fname);
$info = chk_f($fname, $files);

if (file_exists('/var/www/html/statso/ext_logs/'.$fname)) {	
    $data = file('/var/www/html/statso/ext_logs/'.$fname,FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    $final_array = array();

  date_default_timezone_set('Asia/Karachi');
  $now = date("d-m-Y H:i:s", time());
  $index=0;
  foreach ($data as $key=> $dat){
    
      $final_data = explode('|',$dat);  
      $index++;
      $datetime = date("Y-m-d H:i:s",strtotime($final_data[0]));

      $sessionid = $final_data[2];
      $publisher = $final_data[3]; 
      $username = $final_data[8];
      $hostname_ip = $final_data[14];

      if($hostname_ip!=''){
        $ses_res = check_exist($conn, $username, $sessionid, $datetime);
        if($ses_res >= 1){
          echo('Aleready existed ');
        }else{
          $log_insert_query = "INSERT INTO userstats (session_id, log_date, user, sp, ip_address) VALUES('$sessionid','$datetime', '$username', '$publisher', '$hostname_ip')"; 
          $result =  mysqli_query($conn, $log_insert_query);
print_r($result);
	  echo ($log_insert_query);	  
	  echo('success');
        }

    }
  }

    }
}

function glob_files($source_folder, $fname){ //find file from folder here
        if( !is_dir( $source_folder ) ) {
            //die ( "Invalid directory.\n\n" );
          return 1;
        }
        $FILES = glob($source_folder."/$fname*");
        foreach($FILES as $key => $file) 
           {
              $FILE_LIST[$key] = $file; 
           } 
        if(!empty($FILE_LIST)){ return $FILE_LIST; } else {
            //die($fname." file Not found in ".$source_folder." folder \n\n"  );
          return 1;
        }
    }

function chk_f($fname, $files){
    foreach($files as $file)
      {
        $zp = @gzopen($file, "r");
        #//$tmpfolder = tempnam("/var/www/html/statso/ext_logs/","");
        $fp = @fopen('/var/www/html/statso/ext_logs/'.$fname, "a");
              chmod('/var/www/html/statso/ext_logs/'.$fname, 0777);
        while(!@gzeof($zp)) {
          $string = @gzread($zp, 4096);
          @fwrite($fp, $string, strlen($string));
        }
        @gzclose($zp);
        @fclose($fp);
      }

    }


function check_exist($conn, $user, $sessionid, $datetime){
  $con = $conn;
  $ses = $sessionid;
  $u = $user; 
  $query_check="SELECT session_id, log_date, user, sp, ip_address FROM userstats WHERE session_id ='$sessionid' AND user='$user' AND log_date= '$datetime' ";
  $result = mysqli_query($conn, $query_check);
 $rows = mysqli_num_rows($result);
 return $rows;
}

?>


