
<?php
ini_set('memory_limit', '-1');
ini_set('max_execution_time', -1);
require __DIR__ . '/vendor/autoload.php';

//include '../dbconfig';
 include '../dbconfig.php'; 
#$sdate='2020-04-17';
#$edate='2020-04-20';
/*$sdate=$_POST['start'];
$edate=$_POST['end'];*/
/*$startdate=date("Y-m-d", strtotime($sdate));
$enddate=date("Y-m-d", strtotime($edate));*/
$source_folder ="logs";
$pattern="idp-audit.log*";
$files=glob_files($source_folder,$pattern);
function glob_files($source_folder,$pattern){
    if( !is_dir( $source_folder ) ) {
        die ( "Invalid directory.\n\n" );
    } 
    $FILES = glob($source_folder."/$pattern*");
    
    foreach($FILES as $key => $file) 
       {
        $FILE_LIST[$key] = $file;         
        }      
    
    if(!empty($FILE_LIST)){
        return $FILE_LIST;
    } else {
        die( "No files found!\n\n" );
    }
}
$sql = 'SELECT spname,entityid FROM spdetails'; 
$retval = mysqli_query($conn,$sql );

if(! $retval ) { 
    die('Could not get data: ' . mysqli_error());
}
$index=0;
while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
  $stats[$index] = $row; 
  $index++;
}  
function in_array_($array, $column,$field, $find){
    $value= $find;
    foreach($array as $key=> $dat)
    { 
    if($array[$key][$field] == $find){
      $value=$array[$key][$column];
    }    
  }
  return $value;
}


foreach($files as $file)
{    
$zp = @gzopen($file, "r");
$fp = @fopen("idp-audit-2019-07-10.log", "a");
while(!@gzeof($zp)) {$string = @gzread($zp,4096); @fwrite($fp, $string, strlen($string));}
@gzclose($zp);
@fclose($fp);
}
if (file_exists("idp-audit.log")) { 

$data = file("idp-audit.log",FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES); //$argv[1]
$final_array = array(); 

date_default_timezone_set('Asia/Kolkata'); 
$now = date("d-m-Y H:i:s", time()); 
$index=0; 
foreach ($data as $key=> $dat){ 
  
    $final_data = explode('|',$dat); 

    // print_r($dat);
   // $logdate =date("Y-m-d",strtotime($final_data[0]));
    /* if (($logdate >= $startdate) && ($logdate <= $enddate)){ */
    /* $final_array[$index]['datetime'] =date("d-m-Y H:i:s",strtotime($final_data[0])); 
    $final_array[$index]['rp']    = in_array_($stats,'spname' ,'entityid', $final_data[3]);
    $final_array[$index]['idp']   = $final_data[5]; 
    $final_array[$index]['user']  = $final_data[8]; 
    $final_array[$index]['ip']    = $final_data[13]; 
    */
    $index++;

    $datetime = date("d-m-Y H:i:s",strtotime($final_data[0])); 
      /*$month = (date('m', strtotime($date))); 
      $year = (date('Y', strtotime($date))); */ 
    $sessionid = $final_data[2]; 
    $publisher = $final_data[3]; 
    $username = $final_data[8]; 
    $hostname_ip = $final_data[13]; 

    if($hostname_ip!=''){ 
      $ses_res = check_exist($conn, $username, $sessionid); 
      if($ses_res >= 1){
        // update here 
        $log_update_query="";
        $result = mysqli_query($conn, $log_update_query);
      }else{
        // insert here 
        $log_insert_query = "INSERT INTO userstats (log_date, user, sp, ip_address) VALUES('$datetime', '$username', '$publisher', '$hostname_ip')"; 
        $result =  mysqli_query($conn, $log_insert_query);
      }
      die;

      /*$log_insert_query = "INSERT INTO userstats (log_date, user, sp, ip_address) VALUES('$datetime', '$username', '$publisher', '$hostname_ip')"; 
     $result =  mysqli_query($conn, $log_insert_query);
*/
     if($result!=''){
    //  print_r($result);
    }
      echo('success'); 
    }
    
/*}*/
} die;
$f = @fopen("idp-audit.log", "w+"); 
if ($f !== false) {
    ftruncate($f, 0); 
    fclose($f);
}
function array_count($arrs,$id) {
    $ret_array = array();
    foreach($arrs as $h) $ret_array[strtolower($h[$id])]++;
    return $ret_array;
  }
/*  function count_duser($arrs,$id) {
    $ret_array = array();
    foreach($arrs as $val){
        if(in_array('2017-12-19' , $val)){
          $ret_array[strtolower($h[$id])]++;
        }
         return $ret_array;
   /* 
    foreach($arrs as $h) $ret_array[strtolower($h[$id])]++;
   
  }
}*/
if (!isset($final_array)) 
    $final_array = null;
function total_count($arrs) { 
  return count($arrs);
 }

 function unique_sort($arrs) { 
  return count(array_unique($arrs));
 }
 function unique_($arrs, $id) { 
    $unique_arr = array();
    foreach ($arrs as $h) {
    array_push($unique_arr,$h[$id]); 
}   
  return array_unique($unique_arr);
}
if(!empty($final_array)){
$unique_rp =unique_($final_array, 'rp');
$unique_user =unique_($final_array,'user');
$count_logins =unique_sort($unique_rp);
$count_unique_rp =unique_sort($unique_rp);
$count_unique_user =unique_sort($unique_user);
              
                  $jsonObj->logs =$final_array;
$jsonObj->count_unique_rp=unique_sort($unique_rp);
$jsonObj->count_unique_user=unique_sort($unique_user);
$jsonObj->count_total_logins=total_count($final_array);
$jsonObj->count_per_user=array_count($final_array,'user');
$jsonObj->count_per_rp=array_count($final_array,'rp');

/*$jsonObj->count_per_date=count_duser($final_array,'datetime');*/
/*$fp = fopen('stats.json', 'w');
fwrite($fp,json_encode($jsonObj));
fclose($fp);*/

echo json_encode($jsonObj);
    }/* else {
        die( "No Data found!\n\n" );
    }*/


}/*\ else {

    echo "The file $filename does not exist";
}
*/

/*$sql = "SELECT Lastname, Age FROM Persons ORDER BY Lastname";

if ($result = $mysqli -> query($sql)) {
  while ($row = $result -> fetch_row()) {
    printf ("%s (%s)\n", $row[0], $row[1]);
  }*/

function check_exist($conn, $user, $sessionid){
 // $check_query = "SELECT * FROM userstats WHERE session_id = $sessionid AND username= $user" ;
  $query = "SELECT count(totalhit_count) as c FROM userstats WHERE session_id = $sessionid AND username= $user ";
  /*$result = mysqli_query($conn, $query);
  $row = $result->fetch_assoc();*/

  if($result =$conn -> query($query)) {
    while ($row = $result-> fetch_row()) {
      //print_f($row);
      return $row;
    }
  }
 
 // return $row;
}

?>

