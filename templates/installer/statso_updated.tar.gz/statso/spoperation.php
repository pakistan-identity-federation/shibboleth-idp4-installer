<?php include 'dbconfig.php'; 

if(isset($_POST['register']))
{

 		   
        $publisher        = mysql_real_escape_string($_POST['rp']);
        $entityid         = mysql_real_escape_string($_POST['entityid']);     
        
        
$sql_query = "INSERT INTO spdetails(spname,entityid)
            VALUES('$publisher','$entityid')";
 $retval = mysqli_query($conn,$sql_query);
 
 if(! $retval ) {
 $msg="<strong>Oh snap!</strong> ERROR ! could not register";
      Header( 'Location:listpublisher.php?error=1&msg='.$msg );
      
     
   }
   else{
      $msg="<strong>SUCCESS</strong> registered successfully";
   Header( 'Location:listpublisher.php?success=1&msg='.$msg) ;
   }

  
   

     

}
if(isset($_POST['edit']))
{
		    $Id               =mysqli_real_escape_string($_POST['id']);
 		    $publisher        = mysqli_real_escape_string($_POST['rp']);
        $entityid         = mysqli_real_escape_string($_POST['entityid']);     
        

$sql_query = "UPDATE spdetails SET spname = ' $publisher',entityid = '$entityid' WHERE id='$Id'";
    $retval =  mysqli_query($conn,$sql_query);
 if(! $retval ) {
 $msg="<strong>Oh snap!</strong> ERROR ! could not update data";
      Header( 'Location:  listpublisher.php?error=1&msg='.$msg );
   }
   $msg="<strong>SUCCESS</strong> Changes are saved successfully";
   Header( 'Location:  listpublisher.php?success=1&msg='.$msg) ;
 

}
                
 if(isset($_GET['delete']))
{
		$Id=mysqli_real_escape_string($_GET['id']);

$sql_query = "DELETE FROM spdetails WHERE id='$Id'";
    $retval =  mysqli_query($conn,$sql_query)
    
 $retval =  mysqli_query($conn,$sql_query);
	 if(! $retval  ) {

 	$msg="<strong>Oh snap!</strong> ERROR ! could not delete data";
      Header( 'Location: listpublisher.php?error=1&msg='.$msg );
   }else{
   $msg="<strong>SUCCESS</strong> Deleted successfully";
   Header( 'Location: listpublisher.php?success=1&msg='.$msg) ;
  }
   
}
if(isset($_POST['save']))
{
		$Id=$_POST['id'];
 		
        $registered = (isset($_POST['registered'])) ? 1 : 0;
        $in_progress = (isset($_POST['in_progress'])) ? 1 : 0;
        $completed = (isset($_POST['completed'])) ? 1 : 0;
        $support=(isset($_POST['support'])) ? 1 : 0;
        $sql_query = "UPDATE sp_info SET registered=$registered, in_progress = $in_progress,completed = $completed,support=$support WHERE id='$Id'";
        $retval =  mysqli_query($conn,$sql_query);
 

 	
       if(! $retval ) {
      $msg="<strong>Oh snap!</strong> Could not update service provider
       status";
      Header( 'Location: listSP.php?error=1&msg='.$msg  );
   }
   $msg="<strong>SUCCESS</strong> service provider status updated successfully";
   Header( 'Location: listSP.php?success=1&msg='.$msg   );
  

}

 ?>     
