<?php
   session_start();
   unset($_SESSION["username"]);
   header('Refresh: 1; URL = login.php');
?>


