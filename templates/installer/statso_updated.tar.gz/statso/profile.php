<?php

 include 'header.php'; 
 include 'dbconfig.php';
?>
<div id="content">
<div class="container">
<div class="crumbs">
<ul id="breadcrumbs" class="breadcrumb">
<li>
<i class="icon-home">
</i>
<a href="index.php">Dashboard</a>
</li>
<li class="current">
<a href="index.php" title="">User Details</a>
</li>
</ul>
<ul class="crumb-buttons">
<li>
<a href="index.php" title="">
<i class="icon-signal">
</i>
<span>Statistics</span>
</a>
</li>
<li class="dropdown">
<a href="#" title="" data-toggle="dropdown">
<i class="icon-tasks">
</i>
<span>Publishers<strong></strong>
</span>
<i class="icon-angle-down left-padding">
</i>
</a>
<ul class="dropdown-menu pull-right">

<li>
<a href="listpublisher.php" title="">
<i class="icon-reorder">
</i>List Publisher</a>
</li>
</ul>
</li>

</ul>
</div>
<div class="page-header">
<div class="page-title">
<h3>User Profile</h3>

</div>

</div>



 <!-- <div class="row row-bg">
</div> -->

<div class="row row-bg">
</div>



<div id="row">
	 <?php  if ( isset($_GET['success']) && $_GET['success'] == 1 )
                                      {?>
     
                                        <div class="alert alert-success">                
                  
                                            <?php echo $_GET['msg']?> 
                                </div> 
                        <?php }
         
                            if ( isset($_GET['error']) && $_GET['error'] == 1 )
                                {?>
                                 <div class="alert alert-danger">                
                  
                                <?php echo $_GET['msg']?> 
                                </div> 
                                                                             
                                <?php  }
                                ?>  
<div class="col-md-12">
<div class="widget box">
<div class="widget-header">

</div>
<div class="widget-content">
<form class="form-horizontal row-border" action="profileMgt.php" method="post">
	<?php
               
              $username=$_SESSION['username'];
              
              $sql = "SELECT * FROM users WHERE username='$username' ";
             
              $retval = mysql_query( $sql, $conn );

              if(! $retval ) {
                  die('Could not get data: ' . mysql_error());
              }

              while($row = mysql_fetch_array($retval, MYSQL_ASSOC)) {
   ?>              
	 <input type="hidden"  id="id" name="id" value="<?php echo $row['id'] ?>" >
<div class="form-group">
<label class="col-md-2 control-label">Name:</label>
<div class="col-md-10">
<input type="text" name="name" class="form-control" value="<?php echo $row['name'] ?>">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Username:</label>
<div class="col-md-10">
<input class="form-control" type="text" name="username" value="<?php echo $row['username'] ?>">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Email:</label>
<div class="col-md-10">
<input class="form-control"  type="text" name="email" value="<?php echo $row['email'] ?>">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Designation:</label>
<div class="col-md-10">
<input class="form-control"  type="text" name="designation" value="<?php echo $row['designation'] ?>">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Role:</label>
<div class="col-md-10">
<input type="text" name="role"disabled="disabled" class="form-control" value="<?php echo $row['role'] ?>">
</div>
</div>
<div class="form-actions">
<input type="submit" name="edit" value="submit" class="btn btn-primary pull-right">
</div>

 <?php
                         }
                       ?> 
 </form>   
</div>
</div>
</div>
</div>
 </div>


</body> 

</html>


    