
<!-- js -->
<script src="assets/js/amcharts.js"></script>
<script src="assets/js/pie.js"></script>
<script src="assets/js/serial.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.12/sorting/datetime-moment.js"></script>

<!-- priyesh -->
<script type="text/javascript" src="plugins/datatables/jquery.dataTables.min.js"></script>

<script src="assets/js/export.min.js"></script>

<script src="assets/js/light.js"></script>

<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js">
</script>
<script type="text/javascript" src="plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js">
</script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js">
</script>
<script type="text/javascript" src="assets/js/libs/lodash.compat.min.js">
</script>

<script type="text/javascript" src="plugins/touchpunch/jquery.ui.touch-punch.min.js"></script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.move.js"></script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.swipe.js"></script>
<script type="text/javascript" src="assets/js/libs/breakpoints.js"></script>
<script type="text/javascript" src="plugins/respond/respond.min.js"></script>
<script type="text/javascript" src="plugins/cookie/jquery.cookie.min.js"></script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.horizontal.min.js"></script>

<script type="text/javascript" src="plugins/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="plugins/blockui/jquery.blockUI.min.js"></script>
<script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js"></script>
<script type="text/javascript" src="plugins/select2/select2.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js">
</script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js ">
</script>

<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/plugins.js"></script>
<script type="text/javascript" src="assets/js/plugins.form-components.js"></script>
<script>$(document).ready(function(){App.init();Plugins.init();FormComponents.init()});</script>
<script type="text/javascript" src="assets/js/custom.js"></script>

</html>
