<?php
$selector = bin2hex(random_bytes(8));
echo $selector;
?>