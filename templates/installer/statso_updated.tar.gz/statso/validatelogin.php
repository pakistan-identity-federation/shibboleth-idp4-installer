<?php include 'dbconfig.php'; ?>   
<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
   $msg="<strong>ERROR !</strong> Incorrect Username and Password ";
      Header( 'Location:  login.php?error=1&msg='.$msg);

}
//else if($_POST['captcha'] != $_SESSION['digit'])
  //  {
    //     $msg="<strong>ERROR !</strong>The Validation code does not match!";
      //    Header( 'Location:  login.php?error=1&msg='.$msg);
//    } 
else
{

$username=$_POST['username'];
$password=md5($_POST['password']);
/*$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);*/

$sql="SELECT * FROM users WHERE username='$username' and password='$password'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count==1){

  $sql = "SELECT * FROM users WHERE username='$username' and password='$password'";
             
              $retval = mysqli_query($conn,$sql);
              if(! $retval ) {
                  die('Could not get data: ' . mysqli_error());
              }

              while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
       
               $_SESSION['username'] =$row['username'];
              
               header('Location: index.php');
           
              }
}
else {
  
 $msg=" <strong> ERROR!!! </strong>Incorrect Username and Password ";
 Header( 'Location:  login.php?error=1&msg='.$msg);
}
 
}
}
?>
