<?php
 include 'header.php'; 
?>

<div class="content">
<div class="workplace">
    <div class="row">

                    <div class="col-md-12">
                        <div class="head clearfix">
                            <div class="isw-graph"></div>
                            <h1>Get Statistics</h1>
                        </div>
                        <div class="block-fluid">                        
                           
                            <div class="row-form clearfix">
                                <div class="col-md-2">Select Date :</div>
                                <div class="col-md-10"> <div id="reportrange" class="pull-left" style="background: #fff; cursor: pointer; margin-left: 20px;  padding: 5px 10px; border: 1px solid #ccc;">
                                   <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                   <span>Select Date:</span> <b class="caret"></b>
                                  </div></div>
                            </div> 
                            
                                        
                        </div>

                    </div>
                </div>


            <div class="dr"><span></span></div>
        
                  <div class="row" id="stats1">
                    <div class="col-md-4">
                <div class="infoBlock ">                            
                            <div class="iB_content tac">
                                <span class="mChartBar" sparkType="bar" sparkWidth="100%" sparkHeight="50" sparkBarColor="#FFFFFF" sparkBarWidth="10">5,10,15,20,23,21,25,20,15,10,25,20,10</span>    
                            </div>
                            <div class="iB_toolbar">
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="iB_info">
                                            <span class="val" id="uidstotal"></span>
                                            <span>Total Unique user's count </span>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
            </div>
            <div class="col-md-4">
                <div class="infoBlock ">                            
                            <div class="iB_content tac">
                                <span class="mChartBar" sparkType="bar" sparkWidth="100%" sparkHeight="50" sparkBarColor="#FFFFFF" sparkBarWidth="10">5,10,15,20,23,21,25,20,15,10,25,20,10</span>    
                            </div>
                            <div class="iB_toolbar">
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="iB_info">
                                            <span class="val"  id="rptotal"></span>
                                            <span>Total Unique publisher's count</span>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
            </div>
            <div class="col-md-4">
                <div class="infoBlock ">                            
                            <div class="iB_content tac">
                                <span class="mChartBar" sparkType="bar" sparkWidth="100%" sparkHeight="50" sparkBarColor="#FFFFFF" sparkBarWidth="10">5,10,15,20,23,21,25,20,15,10,25,20,10</span>    
                            </div>
                            <div class="iB_toolbar">
                                <div class="row">
                                    
                                    <div class="col-md-12">
                                        <div class="iB_info">
                                            <span class="val" id="logintotal"></span>
                                            <span>Total Logins</span>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
                </div>
                    <div class="col-md-12">                    
                        <div class="head clearfix">
                             <div class="isw-users"></div>
                            <h1>Statistics</h1> 
                                                       
                        </div>
                        <div class="block-fluid table-sorting clearfix">

                            <table id="example" cellpadding="0" cellspacing="0" width="100%" class="table" cellspacing="0">
                             <thead>
                                  <tr>
                                        <th >Time</th>
                                        <th >user</th>
                                        <th >sp</th>                  
                                      </tr>
                                  </thead>
                             </table>
                            
                        </div>
                    </div>  
               
                    <div class="col-md-12" >
                  <div class="head clearfix">
                             <div class="isw-documents"></div>
                            <h1>Publisher Statistics</h1>  
                        </div>
                        <div class="block">
                           <div id="chartdiv" style="height:500px"></div>
                        </div>
                    </div> 
                    <div class="col-md-12" >
                   <div class="head clearfix"> 
                             <div class="isw-users"></div>
                            <h1>User Statistics</h1>  
                        </div> 
                        <div class="block"> 
                           <div id="chartdiv1" style="height:500px"></div>
                        </div> 
                    </div> 
                                                   
                      
                    
                </div>  
                
                


</div>
</div>

 <script type="text/javascript">
 $(document).ready(function(e) {
 var div = document.getElementById('stats1');
div.style.display = 'none';

});</script>

<script type="text/javascript">
$(document).ready(function(e) {
 var div = document.getElementById('stats1');
div.style.display = 'none';
});
$(function() {
    var start = moment().subtract(29, 'days');
    var end = moment();
    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        var startdate=start.format('YYYY-MM-DD');
        var enddate=end.format('YYYY-MM-DD');  
            $.ajax({
            url: "getcontent2.php",
            type: "POST",
            data:'start='+startdate+'&end='+enddate,
            success: function(result){  
            function isJson(str) {
             try {
                 JSON.parse(str);
             } catch (e) {
                 return false;
             }
             return true;
              } 
             if(isJson(result)==true){
            document.getElementById("stats1").style.display = "block";
            var obj=JSON.parse(result);
            document.getElementById("logintotal").innerHTML = obj.count_total_logins;
            document.getElementById("rptotal").innerHTML =  obj.count_unique_rp;
            document.getElementById("uidstotal").innerHTML = obj.count_unique_user; 
            var rpstats=[];
            var userstats=[];
            Object.keys(obj.count_per_rp).forEach(function(n,i){
            var v = obj.count_per_rp[n];
                 rpstats.push({ 
                 rp : n,
                 count : v,
                }); 
            });
            Object.keys(obj.count_per_user).forEach(function(n,i){
            var v = obj.count_per_user[n];
                 userstats.push({ 
                 user : n,
                 count : v,               
                });          
          });
           
    
    var chart = AmCharts.makeChart("chartdiv", {
  "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
   "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "20%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "50%",
      "height": "300%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": rpstats,
  "valueField": "count",
  "titleField": "rp",
  "depth3D": 10,
  "angle": 30,
  "outlineAlpha": 0.1,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
    "fileName": "publisherstats", 
  }
});

chart.addListener("init", handleInit);

chart.addListener("rollOverSlice", function(e) {
  handleRollOver(e);
});
var chart = AmCharts.makeChart("chartdiv1", {
    "autoMargins": false,
  "marginTop": 0,
  "marginBottom": 0,
  "marginLeft": 0,
  "width":1500,
  "height":500,
  "type": "pie",
  "startDuration": 0,
   "theme": "light",
  "addClassNames": true,
  "legend":{
    "position":"bottom",
    "marginRight":50,
    "marginLeft":50,
    "autoMargins":false
  },
  "innerRadius": "20%",
  "defs": {
    "filter": [{
      "id": "shadow",
      "width": "200%",
      "height": "200%",
      "feOffset": {
        "result": "offOut",
        "in": "SourceAlpha",
        "dx": 0,
        "dy": 0
      },
      "feGaussianBlur": {
        "result": "blurOut",
        "in": "offOut",
        "stdDeviation": 5
      },
      "feBlend": {
        "in": "SourceGraphic",
        "in2": "blurOut",
        "mode": "normal"
      }
    }]
  },
  "dataProvider": userstats,
  "valueField": "count",
  "titleField": "user",
  "outlineAlpha": 0.1,
  "depth3D": 15,
  "angle": 30,
  "export": {
    "enabled": true,
    "libs": {
            "path": "libs/"
            },
     "fileName": "userstats", 
  }
});

chart.addListener("init", handleInit);

chart.addListener("rollOverSlice", function(e) {
  handleRollOver(e);
});

function handleInit(){
  chart.legend.addListener("rollOverItem", handleRollOver);
}

function handleRollOver(e){
  var wedge = e.dataItem.wedge.node;
  wedge.parentNode.appendChild(wedge);
}
          
            $('#example').DataTable( {
           "dom": '<"top"Bf>rt<"bottom"lip><"clear">',
             "destroy": true,
             "data":obj.logs,
             
             "columns": [
            { "data": "datetime" },
            { "data": "user" },
            { "data": "rp" },         
        ],"buttons": [
            'csv', 'excel', 'pdf', 'print',
        ],},  );
            /* $('#example1').DataTable( {
              "destroy": true,
             "data": rpstats,
             "columns": [
            { "data": "rp" },
            { "data": "count" },        
        ]} );
           $('#example2').DataTable( {
             "destroy": true,
             "data": userstats,
             "columns": [
            { "data": "user" },
            { "data": "count" },        
        ] } );*/
            }else
            {
                alert(result);
            }
          


          },
             error:function(result,status){
               alert("Error!!"+ status + " Plese Try again..");
            }

        });
    }

      $ ('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb); 
});

</script>
<script>

</script>