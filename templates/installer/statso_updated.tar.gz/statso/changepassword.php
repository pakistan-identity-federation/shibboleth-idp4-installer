<!DOCTYPE html>


 <html lang="en"> 

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
<title>Change Password </title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/main.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/login.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
<!--[if IE 7]>
<link rel="stylesheet" href="assets/css/fontawesome/font-awesome-ie7.min.css">
<![endif]-->
<!--[if IE 8]>
<link href="assets/css/ie8.css" rel="stylesheet" type="text/css"/>
<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js">
</script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js">
</script>
<script type="text/javascript" src="assets/js/libs/lodash.compat.min.js">
</script>
<!--[if lt IE 9]>
<script src="assets/js/libs/html5shiv.js">
</script>
<![endif]-->
<script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js">
</script>
<script type="text/javascript" src="plugins/validation/jquery.validate.min.js">
</script>
<script type="text/javascript" src="plugins/nprogress/nprogress.js">
</script>
<script type="text/javascript" src="assets/js/login.js">
</script>
<script></script>
</head>
<body class="login">

<div class="box" style="margin-top:10%;">
    <?php  if ( isset($_GET['success']) && $_GET['success'] == 1 )
                                      {?>
     
                                        <div class="alert alert-success">                
                  
                                            <?php echo $_GET['msg']?> 
                                </div> 
                        <?php }
         
                            if ( isset($_GET['error']) && $_GET['error'] == 1 )
                                {?>
                                 <div class="alert alert-danger">                
                  
                                <?php echo $_GET['msg']?> 
                                </div> 
                                                                             
                                <?php  }
                                ?>
<div class="content">
<form class="form-vertical login-form" action="useroperation.php" onsubmit="return check();" method="POST">
<h3 class="form-title">Change Password</h3>
<div class="alert fade in alert-danger" style="display: none;">
<i class="icon-remove close" data-dismiss="alert">
</i> Enter any username and password. </div>
<div class="form-group">
<div class="input-icon">
<i class="icon-user">
</i>
<input type="password" class="form-control" placeholder="Enter old password" name="oldpass" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter your old password."/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="icon-lock">
</i>
<input type="password" class="form-control" placeholder="Enter new password" id="newpass" name="newpass" pattern="^([a-zA-Z0-9@!$*#]{5,15})$" class="form-control" title="it should contain  minimun 5 characters" data-rule-required="true" data-msg-required="it should contain  minimun 5 characters"/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="icon-lock">
</i>
<input type="password"  class="form-control" placeholder="Retype password" id="renewpass" name="renewpass" pattern="^([a-zA-Z0-9@!$*#]{5,15})$" data-rule-required="true" />
</div>
</div>
<div class="form-actions">

<button type="submit" name="changepass" class="submit btn btn-primary pull-right"> Submit 
</button>
</div>
</form>

</div>

</div>


</body> 

</html>
<script type="text/javascript">
   function check() {
    
    var flag=false;
      var pass2=document.getElementById("newpass").value;
       var pass1=document.getElementById("renewpass").value;
      
        if(pass1 == pass2){
            
            flag=true;
        
        }else{
             
              flag=false;
              <?php $msg="<strong>ERROR!!</strong> Confirm Password does not match!!!";?>
            window.location = 'changepassword.php?error=1&&msg=<?php echo $msg ?>'             
              
        }
return flag;
}
</script>