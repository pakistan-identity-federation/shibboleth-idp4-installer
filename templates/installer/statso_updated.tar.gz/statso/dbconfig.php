<?php
                $dbhost = 'localhost'; 
                $dbuser = 'idp_admin'; 
                /*$dbpass = '1239*idp999';*/
                $dbpass = 'c@mpb3ll'; 
                $db='statso'; 
                $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db); 

                if(! $conn ) {
                  die('Could not connect: ' . mysqli_error());
               }
             
?>
