<?php
   session_start();
   if(!isset($_SESSION['username'] ))
   {
    Header( 'Location: login.php' );
   }
 ?> 
<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
      <title>Dashboard </title>
      <!-- css -->
      <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
      <!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"> -->
      <!-- <script src="../js/jquery-3.5.1.min.js"></script> -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <link rel="stylesheet" href="assets/css/export.css" type="text/css" media="all" />
      <link href="assets/css/main.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/datatable/jquery-ui.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/datatable/dataTables.jqueryui.min.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
      <link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
      <link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
      <!-- <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.12/sorting/datetime-moment.js"></script> -->
      <!-- <script src=" https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js "></script> -->
      <!--[if IE 7]>
      <link rel="stylesheet" href="assets/css/fontawesome/font-awesome-ie7.min.css">
      <![endif]-->
      <!--[if IE 8]>
      <link href="assets/css/ie8.css" rel="stylesheet" type="text/css"/>
      <![endif]-->
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
      <!-- <script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js"></script>
      <script type="text/javascript" src="plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
      <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="assets/js/libs/lodash.compat.min.js"></script>
      
      <script type="text/javascript" src="plugins/touchpunch/jquery.ui.touch-punch.min.js"></script>
      <script type="text/javascript" src="plugins/event.swipe/jquery.event.move.js"></script>
      <script type="text/javascript" src="plugins/event.swipe/jquery.event.swipe.js"></script>
      <script type="text/javascript" src="assets/js/libs/breakpoints.js"></script>
      <script type="text/javascript" src="plugins/respond/respond.min.js"></script>
      <script type="text/javascript" src="plugins/cookie/jquery.cookie.min.js"></script>
      <script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.min.js"></script>
      <script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.horizontal.min.js"></script>
      <script type="text/javascript" src="plugins/sparkline/jquery.sparkline.min.js"></script>
      <script type="text/javascript" src="plugins/daterangepicker/moment.min.js"></script>
      <script type="text/javascript" src="plugins/daterangepicker/daterangepicker.js"></script>
      <script type="text/javascript" src="plugins/blockui/jquery.blockUI.min.js"></script>
      <script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js"></script>
      <script type="text/javascript" src="plugins/select2/select2.min.js"></script>
     
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
      <script type="text/javascript" src="
         https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js
         "></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js "></script>
      <script type="text/javascript" src="assets/js/app.js"></script>
      <script type="text/javascript" src="assets/js/plugins.js"></script>
      <script type="text/javascript" src="assets/js/plugins.form-components.js"></script>
      <script>$(document).ready(function(){App.init();Plugins.init();FormComponents.init()});</script>
      <script type="text/javascript" src="assets/js/custom.js"></script> -->
   </head>

   <body>
      <header class="header navbar navbar-fixed-top" role="banner">
         <div class="container">
            <a class="navbar-brand" href="index.php">
            <img src="assets/img/logos.png" alt="logo"/ style="margin-right:5px;"><strong>PKIFED</strong>Stat</a>
            <ul class="nav navbar-nav navbar-left hidden-xs hidden-sm">
               <li>
                  <a href="index.php">
                  <i class="icon-dashboard">
                  </i> Dashboard </a>
               </li>
               <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-book">
                  </i>Publisher Details  <i class="icon-caret-down small">
                  </i>
                  </a>
                  <ul class="dropdown-menu">
                     <li>
                        <a href="listpublisher.php">
                        <i class="icon-reorder">
                        </i> View Publishers </a>
                     </li>
                  </ul>
               </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
               <li class="dropdown user">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="icon-user">
                  </i>
                  <span class="username"><?php echo $_SESSION['username'] ?></span>
                  <i class="icon-caret-down small">
                  </i>
                  </a>
                  <ul class="dropdown-menu">
                     <li>
                        <a href="profile.php">
                        <i class="icon-user">
                        </i> Profile</a>
                     </li>
                     <li>
                        <a href="changepassword.php">
                        <i class="icon-lock">
                        </i> Change Password</a>
                     </li>
                     <li class="divider"></li>
                     <li>
                        <a href="logout.php">
                        <i class="icon-key">
                        </i> Log Out</a>
                     </li>
                  </ul>
               </li>
            </ul>
         </div>
      </header>
      <body>
      <div id="container">


