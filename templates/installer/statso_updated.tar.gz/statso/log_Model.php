<?php

function fetch_logs($conn){
	$fetch_sql= "SELECT id, log_date, user, sp, ip_address FROM userstats"; 
	$result = mysqli_query($conn,$fetch_sql); 
	//$rows = mysqli_fetch_object($result);
	$rows = $result -> fetch_all(MYSQLI_ASSOC);
	return $rows;
}

?>