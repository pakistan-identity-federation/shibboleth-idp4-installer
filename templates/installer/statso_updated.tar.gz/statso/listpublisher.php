<?php

 include 'header.php'; 
 include 'dbconfig.php';
?>
<div id="content">
<div class="container">
<div class="crumbs">
<ul id="breadcrumbs" class="breadcrumb">
<li>
<i class="icon-home">
</i>
<a href="index.php">Dashboard</a>
</li>
<li class="current">
<a href="listpublisher.php" title="">Publisher details</a>
</li>
</ul>
<ul class="crumb-buttons">
<li>
<a href="index.php" title="">
<i class="icon-signal">
</i>
<span>Statistics</span>
</a>
</li>


</ul>
</div>
<div class="page-header">
<div class="page-title">
<h3>Publisher Details</h3>
<span>Contains the details of Publishers</span>
</div>



<?php
$count = mysqli_query("SELECT count(*) from spdetails;");
$pubc= mysqli_fetch_assoc($count);
?>

<div class="col-sm-6 col-md-2 hidden-xs" style=" float: right;
    padding-top: 25px;
    margin-bottom: -10px;">
<div class="statbox widget box box-shadow">
<div class="widget-content">
<div class="visual green">
<i class="icon-book">
</i>
</div>
<div class="title">Total Publishers</div>
<div class="value" ><?php echo $pubc?></div>
</div>
</div>
</div>
</div>



 <!-- <div class="row row-bg">
</div> -->




<div id="row">

 
    <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×/button>
          <h4 class="modal-title">Publisher Details</h4>
        </div>
        <div class="modal-body"> 
<div class="widget-content">
<form class="form-horizontal row-border" action="spoperation.php" method="post">
    <input type="hidden" id="id" name="id" value=""/>
<div class="form-group">
<label class="col-md-2 control-label">Publisher</label>
<div class="col-md-10">
<input class="form-control" type="text" id="rp" name="rp">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Entity ID</label>
<div class="col-md-10">
<input class="form-control" id="entityid" name="entityid" >
</div>
</div>
<form>
 </div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<input  class="btn btn-primary" type="submit" name="edit">
</form>
     </div>
   </div>
 </div>
</div>


     <?php  if ( isset($_GET['success']) && $_GET['success'] == 1 )
                                      {?>
     
                                        <div class="alert alert-success">                
                  
                                            <?php echo $_GET['msg']?> 
                                </div> 
                        <?php }
         
                            if ( isset($_GET['error']) && $_GET['error'] == 1 )
                                {?>
                                 <div class="alert alert-danger">                
                  
                                <?php echo $_GET['msg']?> 
                                </div> 
                                                                             
                                <?php  }
                                ?>  
  <div class="row">
   

<div class="modal fade" id="myModal1">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">Add Publisher</h4>
</div>
<div class="modal-body"> 
<div class="widget-content">
<form class="form-horizontal row-border" action="spoperation.php" method="post">
<div class="form-group">
<label class="col-md-2 control-label">Publisher</label>
<div class="col-md-10">
<input class="form-control" type="text" id="rp" name="rp">
</div>
</div>
<div class="form-group">
<label class="col-md-2 control-label">Entity ID</label>
<div class="col-md-10">
<input class="form-control" id="entityid" name="entityid" >
</div>
</div>
<form>
 </div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<input  class="btn btn-primary" type="submit" name="register">
</form>
</div>
</div>
</div>
</div>


<div class="row">
<div class="col-md-12">
<div class="widget box">
<div class="widget-header">
<h4>
<i class="icon-book">
</i> Publisher Details</h4>
</div>
<div class="widget-content">
<div class="tabbable tabbable-custom">
<ul class="nav nav-tabs">

<div class="tab-content">
<div class="tab-pane active" id="tab_feed_1">
  <button style="margin:5px;" class="btn btn-default"  data-toggle="modal" data-target="#myModal1"  data-id="2" data-rp="<?php echo $row['spname']?>" ><i class="icon-plus">
</i>Add new</button>   

    <table id="ex1" class="table  table-bordered table-hover table-checkable table-tabletools datatable " width="100%" cellspacing="0">
        <thead style="background: #F9F9F9;">
            <tr>
                                <th >Publisher</th>
                                <th >Entity ID</th>  
                                <th >Action</th>  
                
            </tr>
        </thead>
        
        <tbody>
            <?php 
                        $sql = 'SELECT * FROM spdetails';

                        $retval = mysqli_query($conn,$sql);

                        if(! $retval ) {
                            die('Could not get data: ' . mysql_error());
                        }

                        while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
                            ?>  
                            <tr>
                                <td ><?php echo $row['spname'] ?></td>
                                <td ><?php echo $row['entityid'] ?></td>
                                 <td style="text-align:center;"><i class="glyphicon glyphicon-pencil" aria-hidden="true" style="margin-left:5px; color:#46AF4A;font-size:15px;" id="getdetail" data-toggle="modal" data-target="#con-close-modal" data-id="<?php echo $row['id']?>" data-rp="<?php echo $row['spname']?>" data-entityid="<?php echo $row['entityid'] ?>"></i>
                                    <a href="spoperation.php?id=<?php echo $row['id']?>&delete=1"><i class="glyphicon glyphicon-trash" style="margin-left:5px; color:#E61919;font-size:15px;" onClick="return confirm('Are you sure to delete <?php echo $row['spname']?> ?')"></i> </a></td>

                            </tr>
                            <?php         
                        }
                        
                        ?>   

        </tbody>
    </table>
</div>

</div>
</div>
</form>

</div>
</div>
</div>

</body> 

</html>



 <script type="text/javascript">

 $(document).ready(function() {
    $('#ex1').DataTable({
            dom: 'Bfrtip',
            "lengthMenu": [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
        buttons: ['pageLength',
           {
                extend: 'collection',
                text: 'Export',
                buttons: [
                    {
                extend: 'excel',
                title: 'Publishers',
                exportOptions: {
                    columns: [ 0, 1,  ]
                }
            },
             {
                extend: 'csv',
                title: 'Publishers',
                exportOptions: {
                    columns: [ 0, 1,  ]
                }
            },
             {
                extend: 'pdf',
                 title: 'Publishers',
                exportOptions: {
                    columns: [ 0, 1,  ]
                }
            },
            {
                extend: 'print',
                title: 'Publishers',
                exportOptions: {
                    columns: [ 0, 1,  ]
                }
            },
                    
                ]
            }
        ]
    });
} );

 </script>
 <script type="text/javascript">
$(document).ready(function(){

$(document).on('click', '#getdetail', function(e){
               
     var id = $(this).data('id');
     var rp = $(this).data('rp');
    
     var entityid= $(this).data('entityid');
       $(".modal-body #id").val( id );
      $(".modal-body #rp").val( rp );
      $(".modal-body #entityid").val(entityid);
     
      
    });


        });
      </script>     
