<!DOCTYPE html>
<!-- online login.php file -->

 <html lang="en"> 
<!-- Mirrored from envato.stammtec.de/themeforest/melon/ui_general.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Feb 2018 10:07:56 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
<title>Login </title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<!--[if lt IE 9]>
<link rel="stylesheet" type="text/css" href="plugins/jquery-ui/jquery.ui.1.10.2.ie.css"/>
<![endif]-->
<link href="assets/css/main.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/icons.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/login.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="assets/css/fontawesome/font-awesome.min.css">
<!--[if IE 7]>
<link rel="stylesheet" href="assets/css/fontawesome/font-awesome-ie7.min.css">
<![endif]-->
<!--[if IE 8]>
<link href="assets/css/ie8.css" rel="stylesheet" type="text/css"/>
<![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/libs/lodash.compat.min.js"></script>
<!--[if lt IE 9]>
<script src="assets/js/libs/html5shiv.js">
</script>
<![endif]-->
<script type="text/javascript" src="plugins/touchpunch/jquery.ui.touch-punch.min.js">
</script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.move.js"></script>
<script type="text/javascript" src="plugins/event.swipe/jquery.event.swipe.js"></script>
<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="assets/js/libs/breakpoints.js"></script>
<script type="text/javascript" src="plugins/respond/respond.min.js"></script>
<script type="text/javascript" src="plugins/cookie/jquery.cookie.min.js"></script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.min.js">
</script>
<script type="text/javascript" src="plugins/slimscroll/jquery.slimscroll.horizontal.min.js">
</script>
<script type="text/javascript" src="plugins/sparkline/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="plugins/daterangepicker/daterangepicker.js">
</script>
<script type="text/javascript" src="plugins/blockui/jquery.blockUI.min.js">
</script>
<script type="text/javascript" src="plugins/pickadate/picker.js"></script>
<script type="text/javascript" src="plugins/pickadate/picker.date.js"></script>
<script type="text/javascript" src="plugins/pickadate/picker.time.js"></script>
<script type="text/javascript" src="plugins/bootstrap-colorpicker/bootstrap-colorpicker.min.js">
</script>
<script type="text/javascript" src="plugins/noty/jquery.noty.js"></script>
<script type="text/javascript" src="plugins/noty/layouts/top.js"></script>
<script type="text/javascript" src="plugins/noty/themes/default.js"></script>
<script type="text/javascript" src="plugins/nprogress/nprogress.js"></script>
<script type="text/javascript" src="plugins/bootbox/bootbox.min.js"></script>
<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/plugins.js"></script>
<script type="text/javascript" src="assets/js/plugins.form-components.js"></script>
<script>$(document).ready(function(){App.init();Plugins.init();FormComponents.init()});</script>
<script type="text/javascript" src="assets/js/custom.js">
</script>
<script type="text/javascript" src="assets/js/demo/ui_general.js">
</script>
<script type="text/javascript" src="assets/js/libs/lodash.compat.min.js">
</script>
<!--[if lt IE 9]>
<script src="assets/js/libs/html5shiv.js">
</script>
<![endif]-->
<script type="text/javascript" src="assets/js/libs/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="plugins/uniform/jquery.uniform.min.js"></script>
<script type="text/javascript" src="plugins/validation/jquery.validate.min.js"></script>
<script type="text/javascript" src="plugins/nprogress/nprogress.js"></script>
<script type="text/javascript" src="assets/js/login.js"></script>
</head>

<body  class="login">
<div class="header">
  <a href="#" class="hlogo"><img src="assets/img/logo.png" alt="logo"/ style="margin-right:5px;"><strong>PKIFED</strong>Stat</a>
  <h5><span>Shibboleth Identity Provider Statistics</span></h5>
  </div>
<div class="logo">
<!--<img src="assets/img/unilogo1.png" alt=""/> -->
</div>
<div class="box">
     <?php 
         if ( isset($_GET['error']) && $_GET['error'] == 1 )
        {?>
         <div class="alert alert-danger">                

        <?php echo $_GET['msg']?> 
        </div> 
                                                     
        <?php  }
      ?>
<div class="content">
<form class="form-vertical login-form" action="validatelogin.php"  onsubmit="return checkForm(this);" method="POST" id="validation">
<h3 class="form-title">Sign In to your Account</h3>
<div class="alert fade in alert-danger" style="display: none;">
<i class="icon-remove close" data-dismiss="alert">
</i> Enter any username and password. </div>
<div class="form-group">
<div class="input-icon">
<i class="icon-user">
</i>
<input type="text" name="username" class="form-control" placeholder="Username" autofocus="autofocus" data-rule-required="true" data-msg-required="Please enter your username."/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="icon-lock">
</i>
<input type="password" name="password" class="form-control" placeholder="Password" data-rule-required="true" data-msg-required="Please enter your password."/>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<img style="width: 80%;height: 40px;" id="captcha" src="captcha.php" alt="CAPTCHA">
<img style="width: 15%; padding:7px;"  id="reload" src="assets/img/refresh.png">
</div>
</div>

<div class="form-group">
<div class="input-icon">
<i class="icon-lock" >
</i>
<input type="text" name="captcha" id="verification" class="form-control" placeholder="Solve verification" data-rule-required="true" data-msg-required="Please enter Captcha.">
</div>
</div>
<div class="form-actions">

<button type="submit" name="submit" class="submit btn btn-primary pull-right"> Sign In <i class="icon-angle-right">
</i>
</button>
</div>
</form>

</div>


</div>
<p class="about"> DISCLAIMER:The information contained in this PKIFEDStat is subject to change by PKIFED Team without any prior notice.
PKIFED gives no warranty of any kind whatsoever, either explicitly or implicitly. It is created for the purpose of assisting the Institution
in more easily adopting the use of the PKIFED.</p>

<footer class="footer-distributed">

      <div class="footer-left">
        <h3>PKIFED |<span> Pakistan Identity Fedaration</span></h3>

        <p class="footer-links">Know more at :
          <a href="https://pkifed.pk/" style="border-bottom: 1px solid #E3761B;">https://pkifed.pk</a>
        </p>
    
      </div>

      <div class="footer-center">
        <div>
          <i class="icon-map-marker"></i>
          <p>PERN<br>Islamabad<br>Pakistan </p>
        </div>

        <div>
          <i class="icon-envelope"></i>
          <p><a href="mailto:edugain-ot[at]hec.gov.pk">edugain-ot[at]hec.gov.pk</a></p>
        </div>

      </div>

      <div class="footer-right">
        <p class="footer-company-about">
          <span>About PKIFEDStat</span>
          PKIFEDStat generates the statistics of Shibboleth-idp Audit logs. It provides the details of loggedIn user and the details publisher site used by the different users.
        </p>

      </div>

    </footer>

</body> 

</html>
<script>
  $(document).ready(function(){
    $('#captcha').attr('src', 'captcha.php?'+(new Date()).getTime());

    $('#reload').click(function(){
      $('#captcha').attr('src', 'captcha.php?'+(new Date()).getTime());
    });
  });
    /*
    $(function() {
        $('#reload').click(function(){
          $("#captcha").attr("src", "captcha.php?"+(new Date()).getTime());
        });
    });

  function checkForm(form)
  {
    if(!form.captcha.value.match(/^\d{5}$/)) {
      alert('Please enter the CAPTCHA digits in the box provided');
      form.captcha.focus();
      return false;
    }
    return true;
  }
*/
</script>
