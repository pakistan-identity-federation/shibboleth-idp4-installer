<?php
ini_set('memory_limit', '-1');
ini_set('max_execution_time', -1);

require __DIR__ . '../apache2-log-parser-master/vendor/autoload.php';
include 'dbconfig.php';

$source_folder ="logs1";
$pattern="idp-audit";
$ext = '.log';
$y = date('Y'); 
//$m = date('m'); 
$m = date('m', strtotime("-4 month")); 
//$d = $d = (date('d', strtotime("-4 day")));
$d = '20';
$fname = $pattern.'-'.$y.'-'.$m.'-'.$d.$ext; //get dynamic file

print_r($fname);

 /*$fname="idp-audit-2020-06-15";*/
$files=glob_files($source_folder,$fname);

function glob_files($source_folder, $fname){ //find file from folder here
        if( !is_dir( $source_folder ) ) {
            die ( "Invalid directory.\n\n" );
        }
        $FILES = glob($source_folder."/$fname*");
        //print_r($FILES); die;
                
        foreach($FILES as $key => $file) 
           { $FILE_LIST[$key] = $file;} 
        if(!empty($FILE_LIST)){ return $FILE_LIST; } else {
            die($fname." file Not found in ".$source_folder." folder \n\n"  );
        }
    }
$sql = 'SELECT spname,entityid FROM spdetails';
$retval = mysqli_query($conn,$sql );

if(! $retval ) { 
    die('Could not get data: ' . mysqli_error());
}
$index=0;
while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
  $stats[$index] = $row; 
  $index++;
}  
function in_array_($array, $column,$field, $find){
    $value= $find;
    foreach($array as $key=> $dat)
    { 
    if($array[$key][$field] == $find){
      $value=$array[$key][$column];
    }    
  }
  return $value;
} 

foreach($files as $file)
{
  //$name = "idp-audit.log";
  $zp = @gzopen($file, "r");
  $fp = @fopen($fname, "a");
        chmod($fname,0777);
  while(!@gzeof($zp)) {
    $string = @gzread($zp,4096); 
    @fwrite($fp, $string, strlen($string));
  }
  @gzclose($zp);
  @fclose($fp);
}
if (file_exists($fname)) {

  $data = file($fname,FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES); //$argv[1]
  $final_array = array(); 

  date_default_timezone_set('Asia/Kolkata');
  $now = date("d-m-Y H:i:s", time()); 
  $index=0; 
foreach ($data as $key=> $dat){
  
    $final_data = explode('|',$dat);  
    $index++;
    $datetime = date("Y-m-d H:i:s",strtotime($final_data[0])); 

    $sessionid = $final_data[2]; 
    $publisher = $final_data[3]; 
    $username = $final_data[8];
    $hostname_ip = $final_data[13];

    if($hostname_ip!=''){
      $ses_res = check_exist($conn, $username, $sessionid, $datetime);
      if($ses_res >= 1){
        /*
        $log_update_query="";
        $result = mysqli_query($conn, $log_update_query);
        echo('update here');
        */
        //echo('Aleready existed ');
      }else{
       // print_r('insert here'); 
        $log_insert_query = "INSERT INTO userstats (session_id, log_date, user, sp, ip_address) VALUES('$sessionid','$datetime', '$username', '$publisher', '$hostname_ip')"; 
        $result =  mysqli_query($conn, $log_insert_query);
        echo('success');
      }

  }
} 
/*$f = @fopen("idp-audit.log", "w+");
if ($f !== false) {
    ftruncate($f, 0); 
    fclose($f);
}*/

function array_count($arrs,$id) {
    $ret_array = array();
    foreach($arrs as $h) $ret_array[strtolower($h[$id])]++;
    return $ret_array;
  }

if (!isset($final_array)) 
    $final_array = null;
function total_count($arrs) { 
  return count($arrs);
 }

 function unique_sort($arrs) {
  return count(array_unique($arrs));
 }
 function unique_($arrs, $id) {
    $unique_arr = array();
    foreach ($arrs as $h) {
    array_push($unique_arr,$h[$id]); 
}   
  return array_unique($unique_arr);
}
if(!empty($final_array)){
$unique_rp =unique_($final_array, 'rp');
$unique_user =unique_($final_array,'user');
$count_logins =unique_sort($unique_rp);
$count_unique_rp =unique_sort($unique_rp);
$count_unique_user =unique_sort($unique_user);
              
$jsonObj->logs =$final_array;
$jsonObj->count_unique_rp=unique_sort($unique_rp);
$jsonObj->count_unique_user=unique_sort($unique_user);
$jsonObj->count_total_logins=total_count($final_array);
$jsonObj->count_per_user=array_count($final_array,'user');
$jsonObj->count_per_rp=array_count($final_array,'rp');

echo json_encode($jsonObj);
    }
}

function check_exist($conn, $user, $sessionid, $datetime){
  $con = $conn;
  $ses = $sessionid;
  $u = $user;
 
  $query_check="SELECT session_id, log_date, user, sp, ip_address FROM userstats WHERE session_id ='$sessionid' AND user='$user' AND log_date= '$datetime' ";
  $result = mysqli_query($conn, $query_check);
 $rows = mysqli_num_rows($result);
 return $rows; 
 
}

?>

