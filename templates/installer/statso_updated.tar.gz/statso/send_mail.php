<?php
session_start();
 include 'dbconfig.php';
if(isset($_POST['reset_password']))
{


    $email =mysql_real_escape_string($_POST['email']) ;
    $sql="SELECT * FROM users WHERE email='$email'";
    $result=mysql_query($sql);


    $count=mysql_num_rows($result);
    if($count>0){
       
        $salt = "498#2D83B631%3800EBD!801600D*7E3CC13";
        $rndno=rand(1000, 9999);
        /*$resetlink = "http://localhost/simple/dark/forgetpassword.php.php?q=".$password;*/
        $mailMsg  = "OTP : " . $rndno . "";
        $mailto = $_POST['email'];
        $mailSub = 'Reset Password';
    
   require 'PHPMailer-master/PHPMailerAutoload.php';
   $mail = new PHPMailer();
   $mail ->IsSmtp();
   $mail ->SMTPDebug = 0;
   $mail ->SMTPAuth = true;
   $mail ->SMTPSecure = 'ssl';
   $mail ->Host = "smtp.gmail.com";
   $mail ->Port = 465; // or 587
   $mail ->IsHTML(true);
   $mail ->Username = "vbprajapati39@gmail.com";
   $mail ->Password = "";
   $mail ->SetFrom("vbprajapati39@gmail.com");
   $mail ->Subject = $mailSub;
   $mail ->Body = $mailMsg;
   $mail ->AddAddress($mailto);

   if(!$mail->Send())
   {
          $msg="Could not send a mail,Please Try again later." ;   
         Header( 'Location: forgetpassword.php?error=1&msg='.$msg );
   }
   else
   {
      $sql_query = "UPDATE users SET otp = '$rndno',resetflag = 0  WHERE email='$email'";
      $retval = mysql_query($sql_query);
      if(! $retval ) {
          $msg="<strong>Oh snap!</strong> ERROR !Please Try Again Later";
          Header( 'Location:  forgetpassword.php?error=1&msg='.$msg );
      }else
      {
       Header( 'Location:otpvalidation.php');
         $_SESSION['email'] =$email;
      }

   }
}else{
    $msg="User does not exists";   
       Header( 'Location:forgetpassword.php?error=1&msg='.$msg );
}

}



   

