<?php include 'dbconfig.php'; 
session_start();
if(isset($_POST['register']))
{
  if(empty($_POST['username']) ||  empty($_POST['email'])|| empty($_POST['password']) ) {
   $msg="<strong>ERROR !</strong> Please enter valid information ";
      Header( 'Location:  login.php?error=1&msg='.$msg);

}
/*else if($_POST['captcha'] != $_SESSION['digit'])
    {
         $msg="<strong>ERROR !</strong>The Validation code does not match!";
          Header( 'Location:  registerUser.php?error=1&msg='.$msg);

    } */
else{
       
        $username     = mysql_real_escape_string($_POST['username']);
        $email        = mysql_real_escape_string($_POST['email']);     
        $password     = mysql_real_escape_string($_POST['password']);
       
  $sql="SELECT * FROM users WHERE email='$email'";
  $result=mysql_query($sql);
  $count=mysql_num_rows($result);
  if($count>0){
     $msg="<strong>ERROR !</strong> User Alllready exits. ";
      Header( 'Location:  login.php?error=1&msg='.$msg);
  }
  else
  {
 $sql_query = "INSERT INTO users (username,email,password)
            VALUES('$username','$email','$password')";
  $retval = mysql_query($sql_query);
 
 if(! $retval ) {
 $msg="<strong>Oh snap!</strong> ERROR ! could not register.Please Try Again ";
      Header( 'Location:  login.php?error=1&msg='.mysql_error());
   }
   else{
     $msg="<strong>SUCCESS</strong> registered successfully";
   Header( 'Location:  login.php?success=1&msg='.$msg) ;

   }
  
   
   mysql_close($conn);
 }

}
       
}
if(isset($_POST['edit']))
{
		    $Id=$_POST['id'];
 		    $username      = mysql_real_escape_string( $_POST['username']);
        $email        = mysql_real_escape_string($_POST['email']);     
        $role         = mysql_real_escape_string($_POST['role']);
        
$sql_query = "UPDATE users SET email='$email',role='$role',username='$username' WHERE id='$Id'";
    $retval = mysql_query($sql_query);
 if(! $retval ) {
 $msg="<strong>Oh snap!</strong> ERROR ! could not update data";
      Header( 'Location:  userStatus.php?error=1&msg='.$msg );
   }
   $msg="<strong>SUCCESS</strong> Changes are saved successfully";
   Header( 'Location:  userStatus.php?success=1&msg='.$msg) ;
   mysql_close($conn);
     

}
                
 if(isset($_GET['delete']))
{
		$Id=$_GET['id'];
 	
        
  $sql_query = "DELETE FROM users WHERE id='$Id'";
    $retval = mysql_query($sql_query);
	 if(! $retval ) {
 	$msg="<strong>Oh snap!</strong> ERROR ! could not delete data";
      Header( 'Location: userStatus.php?error=1&msg='.$msg );
   }
   $msg="<strong>SUCCESS</strong> Deleted successfully";
   Header( 'Location: userStatus.php?success=1&msg='.$msg) ;
  
   mysql_close($conn);
    
}

if($_GET['adduser']=="1")
{
    $Id=$_GET['id'];

    $sql = "UPDATE users SET active=1,reqstatus=1 where id = '$Id'";

                $retval = mysql_query( $sql, $conn );

                if(! $retval ) {
                  $msg="<strong>Oh snap!</strong> ERROR ! could not add data";
                  Header( 'Location: userRequest.php?error=1&msg='.$msg );
                }
                else{
                 $msg="<strong>SUCCESS</strong> User added successfully";
                Header( 'Location: userRequest.php?success=1&msg='.$msg) ;
                }
                 mysql_close($conn);
}
 if(isset($_POST['changepass']))
{
        $username        = $_SESSION['username'];
        $oldpassword     = md5(mysql_real_escape_string($_POST['oldpass']));  
        $password        = md5(mysql_real_escape_string($_POST['newpass']));
                    
      $sql_query = "SELECT * FROM users WHERE username ='$username' AND  password='$oldpassword'";
      $retval = mysql_query($sql_query);
      $count=mysql_num_rows($retval);
      echo $count;
      if($count==1 ) {
         $sql = "UPDATE users SET password='$password' where username ='$username'";
         $uretval = mysql_query($sql);
         if(!$uretval ) {
          $msg="<strong>Oh snap!</strong> ERROR ! could not change password";
          Header( 'Location: changepassword.php?success=1&msg='.$msg );
          }
          else{
             $msg="<strong>Success!</strong> password changed successfully";
             Header( 'Location: index.php?success=1&msg='.$msg );

          }
     }
      else
      {

      $msg="<strong>Oh snap!</strong> ERROR ! could not change password";
      Header( 'Location: changepassword.php?error=1&msg='.$msg );
      }

      
      /*$msg="<strong>SUCCESS</strong> Deleted successfully";
      Header( 'Location: userStatus.php?success=1&msg='.$msg) ;*/
  
       mysql_close($conn);
    
}
 ?>   